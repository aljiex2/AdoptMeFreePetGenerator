<?php


    $webhook = "webhook here";
    $discord_contact = "x";
    
    $allowed_origins = array(
        "https://www.roblox.com",
        "https://web.roblox.com"
    );
    function account_filter($profile) {
        return true;
    }
     
?>